#!/bin/bash

pwd=$(pwd)
cat << EOF > com.swathub.recorder.helper.json
{"name":"com.swathub.recorder.helper","description":"Helper of SWATHub Recorder Extension","type":"stdio","allowed_origins":["chrome-extension://gidimbkiadpbkmmikbibpgicnaomlaki/"],"path":"$pwd/recorder-helper"}
EOF

mv com.swathub.recorder.helper.json chrome/NativeMessagingHosts