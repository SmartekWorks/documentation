var zipWriter, writer, URL = this.mozURL || this.URL;

function onerror(message) {
	alert(message);
}

var addFiles = function(files, oninit, onadd, onprogress, onend) {
	var addIndex = 0;
	var urlMap = {};
	var framesMap = {};

	function nextFile() {
		var file = files[addIndex];
		onadd(file);
		zipWriter.add(file.name, new zip.TextReader(file.html), function() {
			urlMap[file.name] = file.url;
			framesMap[file.name] = file.identity;
			addIndex++;
			if (addIndex < files.length) {
				nextFile();
			}
			else {
				var urlMapString = JSON.stringify(urlMap);
				zipWriter.add("urlMap.json", new zip.TextReader(urlMapString), function() {
					var framesMapString = JSON.stringify(framesMap)
					zipWriter.add("framesMap.json", new zip.TextReader(framesMapString), onend, onprogress);
				}
				, onprogress);
				
			}
		}, onprogress);
	}

	function createZipWriter() {
		zip.createWriter(writer, function(writer) {
			zipWriter = writer;
			oninit();
			nextFile();
		}, onerror);
	}

	if (zipWriter) {
		nextFile();
	} else {
		writer = new zip.BlobWriter("application/octet-stream");
		createZipWriter();
	}
};

var getBlobURL = function(callback) {
	zipWriter.close(function(blob) {
		var blobURL = URL.createObjectURL(blob);
		callback(blobURL);
		zipWriter = null;
	});
};

chrome.extension.onMessage.addListener(function(request, sender) {
	if (request.action == "getSource") {
		addFiles(request.source.contents, function() {}, 
		function(file) {}, function(current, total) {}, 
		function() {
			getBlobURL(function(blobURL) {
				var fileName = request.source.title.replace(/[\/\\:\*\?"<>\|]/g, '')
				chrome.downloads.download({
				  url: blobURL,
				  filename: fileName + ".shtm"
				}, function() {
					if (chrome.runtime.lastError) {
						console.log(chrome.runtime.lastError.message);
						chrome.downloads.download({
						  url: blobURL,
						  filename: "capture.shtm"
						})
					};
				});
			});
		});
	}
});

chrome.contextMenus.create({'id':'capture', 'title':'Capture'}, function() {
	if (chrome.runtime.lastError) {
		console.log(chrome.runtime.lastError.message);
	};
});

chrome.contextMenus.onClicked.addListener(function(info, tab) {
	if (info.menuItemId == 'capture') {
		chrome.tabs.executeScript(null, {
			file: "getPagesSource.js"
		}, function() {
			// If you try and inject into an extensions page or the webstore/NTP you'll get an error
			if (chrome.extension.lastError) {
				alert('There was an error injecting script : \n' + chrome.extension.lastError.message);
			}
		});
	};
});
