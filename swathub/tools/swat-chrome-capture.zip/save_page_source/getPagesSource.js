function getAllPageSource(doc) {
    var title = doc.title;
    if (!title || title == '') { title = 'pages' };
    var allHtml = {"title":title, "contents":[]};

    var getFramePageSource = function(frame, prefix, url, identity) {
        if (frame.contentDocument) {
            var htmlName = prefix + ".html";

            var cloneFrame = frame.contentDocument.documentElement.cloneNode(true);

            for (var i = 0; i < frame.contentDocument.getElementsByTagName('frame').length; i++) {
                getFramePageSource(
                    frame.contentDocument.getElementsByTagName('frame')[i], 
                    prefix + "-" + i.toString(), 
                    cloneFrame.getElementsByTagName('frame')[i].src,
                    {
                        "name": cloneFrame.getElementsByTagName('frame')[i].name,
                        "id": cloneFrame.getElementsByTagName('frame')[i].id
                    }
                );
                cloneFrame.getElementsByTagName('frame')[i].src = prefix + "-" + i.toString() + ".html";
            };

            for (var i = 0; i < frame.contentDocument.getElementsByTagName('iframe').length; i++) {
                getFramePageSource(
                    frame.contentDocument.getElementsByTagName('iframe')[i],
                    prefix + "-" + (i + frame.contentDocument.getElementsByTagName('frame').length).toString(),
                    cloneFrame.getElementsByTagName('iframe')[i].src,
                    {
                        "name": cloneFrame.getElementsByTagName('iframe')[i].name,
                        "id": cloneFrame.getElementsByTagName('iframe')[i].id
                    }
                );
                cloneFrame.getElementsByTagName('iframe')[i].src = prefix + "-" + (i + frame.contentDocument.getElementsByTagName('frame').length).toString() + ".html";
            };

            allHtml.contents.push({"name":htmlName, "html":cloneFrame.outerHTML, "url":url, "identity":identity});
        };
    };

    var cloneDoc = doc.documentElement.cloneNode(true);

    for (var i = 0; i < doc.getElementsByTagName('frame').length; i++) {
        try {
            getFramePageSource(
                doc.getElementsByTagName('frame')[i], 
                i.toString(), 
                cloneDoc.getElementsByTagName('frame')[i].src,
                {
                    "name": cloneDoc.getElementsByTagName('frame')[i].name,
                    "id": cloneDoc.getElementsByTagName('frame')[i].id
                }
            );
            cloneDoc.getElementsByTagName('frame')[i].src = i.toString() + ".html";
        } catch(err) {
            console.log(err.message);
        }
    };

    for (var i = 0; i < doc.getElementsByTagName('iframe').length; i++) {
        try {
            getFramePageSource(
                doc.getElementsByTagName('iframe')[i], 
                (i + doc.getElementsByTagName('frame').length).toString(), 
                cloneDoc.getElementsByTagName('iframe')[i].src,
                {
                    "name": cloneDoc.getElementsByTagName('iframe')[i].name,
                    "id": cloneDoc.getElementsByTagName('iframe')[i].id
                }
            );
            cloneDoc.getElementsByTagName('iframe')[i].src = (i + doc.getElementsByTagName('frame').length).toString() + ".html";
        } catch(err) {
            console.log(err.message);
        }
    };

    allHtml.contents.push({"name":"main.html", "html":cloneDoc.outerHTML, "url":doc.URL, "identity":{"name":"", "id":""}});

    return allHtml;
}

chrome.extension.sendMessage({
    action: "getSource",
    source: getAllPageSource(document)
});