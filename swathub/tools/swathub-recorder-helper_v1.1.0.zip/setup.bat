@echo off
set "myappdata=%appdata%"
set "myappdata=%myappdata:\=\\%"

@REM create json file
echo {"name":"com.swathub.recorder.helper","description":"Helper of SWATHub Recorder Extension","type":"stdio","allowed_origins":["chrome-extension://gidimbkiadpbkmmikbibpgicnaomlaki/"],"path":"%myappdata%\\swathub-desktop\\recorder\\recorder-helper.exe"}>"com.swathub.recorder.helper.json"

@REM create reg file
echo Windows Registry Editor Version 5.00>"recorder-helper.reg"
echo   [HKEY_CURRENT_USER\Software\Google\Chrome\NativeMessagingHosts\com.swathub.recorder.helper]>>"recorder-helper.reg"
echo   @="%myappdata%\\swathub-desktop\\recorder\\com.swathub.recorder.helper.json">>"recorder-helper.reg"
"recorder-helper.reg"
